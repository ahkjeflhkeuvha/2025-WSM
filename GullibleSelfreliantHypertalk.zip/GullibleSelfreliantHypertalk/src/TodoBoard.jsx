import React from "react";
import ToDoItem from "./ToDoItem.jsx";

function TodoBoard(props) {
  return (
    <div className="TodoBoard">
      <h1>Todo Board</h1>
      {props.todos.map((item, i) => {
        return (
          <div className="Todo">
            <div className="LeftTodo">
              <input type="checkbox" />
              <ToDoItem todo={item} idx={i + 1} />
            </div>
            <button onClick={() => props.deleteTodo(i)}>삭제</button>
          </div>
        );
      })}
    </div>
  );
}

export default TodoBoard;
