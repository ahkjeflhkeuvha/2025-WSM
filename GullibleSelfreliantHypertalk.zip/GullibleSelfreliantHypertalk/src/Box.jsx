function Box(props) {
  function clickMessage() {
    alert("message!");
  }
  return (
    <div className="box">
      {"Box "}
      {props.number} {props.name}
      <button onClick={clickMessage}>button!</button>
    </div>
  );
}

export default Box;
