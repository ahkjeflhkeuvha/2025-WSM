import "./App.css";
import "./ToDoItem.jsx";
import Box from "./Box.jsx";
import { useState } from "react";
import ToDoItem from "./ToDoItem.jsx";
import TodoBoard from "./TodoBoard.jsx";

export default function App() {
  const [todo, setTodo] = useState("");
  const [todos, setTodos] = useState([]);
  const [todoId, setTodoId] = useState(0);

  const onChange = (e) => {
    setTodo(e.target.value);
  };

  const addTodo = () => {
    if (todo) {
      const newTodo = [...todos, todo];
      setTodos(newTodo);
      setTodo("");
      setTodoId(todoId + 1);
    } else {
      alert("투두를 입력해주세요!");
    }
  };

  const deleteTodo = (id) => {
    const res = confirm("정말로 삭제하시겠습니까?");

    if (res) {
      const newTodo = todos.filter((item, i) => i !== id);
      setTodos(newTodo);
    }
  };

  return (
    <main>
      <div className="InputContainer">
        <input type="text" onChange={onChange} value={todo} />
        <button onClick={addTodo}>추가</button>
      </div>
      <TodoBoard todos={todos} deleteTodo={deleteTodo} className="TodoBoard" />
    </main>
  );
}
