import React from "react";

export default function ToDoItem(props) {
  return (
    <div className="TodoItem">
      {props.idx}. {props.todo}
    </div>
  );
}
